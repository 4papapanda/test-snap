// use an integer for version numbers
version = 6


cloudstream {
    language = "id"
    // All of these properties are optional, you can safely remove them

     description = "AnimeSail – Streaming Download Anime Subtitle Indonesia"
     authors = listOf("Hexated", "arranoust")

    /**
     * Status int as the following:
     * 0: Down
     * 1: Ok
     * 2: Slow
     * 3: Beta only
     * */
    status = 0 // will be 3 if unspecified
    tvTypes = listOf(
        "AnimeMovie",
        "Anime",
        "OVA",
    )

    iconUrl = "https://aghanim.xyz/wp-content/themes/animesail/assets/images/ico.png"
}
