version = 1

cloudstream {
    language = "id"
    description = "Zoronime — Anime Sub Indo"
    authors = listOf("Asm0d3usX")
	isCrossPlatform = true
    status = 1
    tvTypes = listOf(
        "AnimeMovie",
        "OVA",
        "Anime"
    )
}
