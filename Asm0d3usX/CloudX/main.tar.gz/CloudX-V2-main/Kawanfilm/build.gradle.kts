version = 1

cloudstream {
    description = "Kawanfilm - Streaming Movie Sub Indo"
    language = "id"
    authors = listOf("Asm0d3usX")
	isCrossPlatform = true
    status = 1
    tvTypes = listOf(
        "AsianDrama",
        "TvSeries",
        "Movie"
    )
}
