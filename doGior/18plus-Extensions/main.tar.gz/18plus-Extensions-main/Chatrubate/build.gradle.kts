version = 2

cloudstream {
    authors     = listOf("luck731", "doGior")
    language    = "en"
    description = "Chaturbate - Free Adult Webcams, Live Sex, Free Sex Chat, Exhibitionist & Pornstar Free Cams"

    /**
     * Status int as the following:
     * 0: Down
     * 1: Ok
     * 2: Slow
     * 3: Beta only
    **/
    status  = 1 // will be 3 if unspecified
    tvTypes = listOf("NSFW")
    iconUrl = "https://web.static.mmcdn.com/favicons/android-chrome-192x192.png?hash=614dfd1c2518"
}
