// use an integer for version numbers
version = 1

cloudstream {
    language = "id"
    // All of these properties are optional, you can safely remove them

    description = "Dubbindo — Streaming Anime, Movie and TV Series"
    authors = listOf("Miku")

    /**
     * Status int as the following:
     * 0: Down
     * 1: Ok
     * 2: Slow
     * 3: Beta only
     * */
    status = 1 // will be 3 if unspecified
    tvTypes = listOf(
        "TvSeries",
        "Movie",
        "Cartoon",
        "Anime",
    )

    iconUrl = "https://www.google.com/s2/favicons?domain=www.dubbindo.site&sz=%size%"
}

android {

    namespace = "com.dubbindo" 
    
    buildFeatures {
        buildConfig = true
    }
    
    defaultConfig {
        val githubPassword = System.getenv("DUBBINDO_PASSWORD") ?: ""
        buildConfigField("String", "DUBBINDO_PASSWORD", "\"$githubPassword\"")
        
        val githubUsername = System.getenv("DUBBINDO_USERNAME") ?: ""
        buildConfigField("String", "DUBBINDO_USERNAME", "\"$githubUsername\"")
    }
}
